# encoding: utf-8
from __future__ import print_function
import logging
import time
import boto3
from botocore.vendored import requests
from boto3.dynamodb.conditions import Key, Attr
import random
# logging module
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # 只輸出INFO & 以上等級的log


recipes = []
recipesItems = []
# meal_type setting
breakfastList = ['蛋餅', '餅', '蛋糕', '蛋塔', '三明治', '舒芙蕾', '吐司', '麵包', '奶酪', '果醬','圓包','麻糬','珍珠','提拉米蘇','水果']
breakfast = []
lunch = []
# ingredients_type setting
recommend = []
eggList = ['雞蛋', '蛋']
vegList = ['菜', '黃瓜', '冬瓜', '絲瓜', '苦瓜', '茄子','豆','菇','茸','秋葵','玉米','洋蔥','馬鈴薯','木耳','蘆筍','筍','青椒']
meatList = ['牛肉', '豬肉', '雞肉', '羊肉', '肉', '培根', '香腸', '火腿','排']
seafoodList = ['鮪魚', '鮭魚','鯛魚','蝦', '蛤蜊', '魷魚','蝦仁','烏賊','活蝦']


# dynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('Recipes')

""" --- Helpers to build responses which match the structure of the necessary dialog actions --- """
def get_slots(intent_request):
    return intent_request['currentIntent']['slots']


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }


def close(session_attributes, fulfillment_state, message, responseCard):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message,
            'responseCard': responseCard
        }
    }

    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }

""" --- recommend recipes  --- """
def classifyMealType(info):
    '''
    classify the meal to breakfast, lunch/dinner
    '''
    breakfastBool = False
    for n in info:
        for i in breakfastList:
            if i in n['Name']:
                breakfastBool = True

        if breakfastBool == True:
            breakfast.append(n)
        else:
            lunch.append(n)
        breakfastBool = False


def recommendRecipe(ingredient_type, meal_type):
    '''
    search ingredients in recipe
    '''
    recommendBool = False
    print(ingredient_type)

    if meal_type == 'Breakfast':
        meal = breakfast

    else:
        meal = lunch

    if ingredient_type == 'Egg':
        ingredientsList = eggList

    elif ingredient_type == 'Veg':
        ingredientsList = vegList

    elif ingredient_type == 'Meat':
        ingredientsList = meatList

    else:
        ingredientsList = seafoodList
        
    print(ingredientsList)

    for n in meal:
        for i in ingredientsList:
            if i in n['Ingredients']:
                recommendBool = True

        if recommendBool == True:
            recommend.append(n)
        else:
            continue
        recommendBool = False
        
    print(recommend)

""" --- Helper Functions --- """
def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            'isValid': is_valid,
            'violatedSlot': violated_slot
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }


def validate_provide_menu(meal_type, ingredient_type):
    meal_types = ['breakfast', 'lunch', 'dinner']
    ingredient_types = ['egg', 'veg', 'meat', 'seafood']

    if meal_type is not None and meal_type.lower() not in meal_types:
        return build_validation_result(False,
                                       'MealType',
                                       'We do not have {} recipes, would you like a different type of meal?'
                                       'Try breakfast?lunch?dinner?'.format(meal_type))

    if ingredient_type is not None and ingredient_type.lower() not in ingredient_types:
        return build_validation_result(False, 'IngredientType',
                                       'We do not have {} recipes, would you like a different type of ingredient?'
                                       'Try veg?meat?fish?egg?'.format(ingredient_type))

    return build_validation_result(True, None, None)


""" --- Functions that control the bot's behavior --- """
def provide_menu(intent_request):
    """
    Performs dialog management and fulfillment for providing menus.
    Beyond fulfillment, the implementation of this intent demonstrates the use of the elicitSlot dialog action
    in slot validation and re-prompting.
    """
    meal_type = get_slots(intent_request)["MealType"]
    ingredient_type = get_slots(intent_request)["IngredientType"]
    source = intent_request['invocationSource']

    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        # Use the elicitSlot dialog action to re-prompt for the first violation
        # detected.
        slots = get_slots(intent_request)

        validation_result = validate_provide_menu(meal_type, ingredient_type)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(intent_request['sessionAttributes'],
                               intent_request['currentIntent']['name'],
                               slots,
                               validation_result['violatedSlot'],
                               validation_result['message'])

        # Pass the recipe of meal type back through session attributes to be used in various prompts defined
        # on the bot model.
        output_session_attributes = intent_request[
            'sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}

        if meal_type is not None:
            print(meal_type)
            classifyMealType(recipesItems)
            if ingredient_type is not None:

                recommendRecipe(ingredient_type, meal_type)
                output_session_attributes = recommend[
                    random.randrange(len(recommend))]
                print(output_session_attributes)
                    
        return delegate(output_session_attributes, get_slots(intent_request))

    # Provide the recipe, and rely on the goodbye message of the bot to define the message to the end user.
    # In a real bot, this would likely involve a call to a backend service.
    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': 'Your {} recipe is '.format(meal_type) +"\n"+ intent_request['sessionAttributes']['Name'] +"\n" + intent_request['sessionAttributes']['Link']
                  },
                 {
        'version': 1,
        'contentType': 'application/vnd.amazonaws.card.generic',
        'genericAttachments': [
            {
                'title': intent_request['sessionAttributes']['Name'],
                'subTitle': intent_request['sessionAttributes']['Description'],
                'imageUrl': intent_request['sessionAttributes']['Img'],
                'attachmentLinkUrl': intent_request['sessionAttributes']['Link']
            }
        ]
    }
    )
    
def check_preference(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    print(recommend)
    source = intent_request['invocationSource']

    if source == 'DialogCodeHook':
        output_session_attributes = recommend[random.randrange(len(recommend))]
        print(output_session_attributes)
        return delegate(output_session_attributes, get_slots(intent_request))
                
    return close(intent_request['sessionAttributes'],
            'Fulfilled',
                     {'contentType': 'PlainText',
                      'content': 'Your new recipe is '+ "\n" + intent_request['sessionAttributes']['Name']+ "\n" +intent_request['sessionAttributes']['Link']
                      },
                     {
                        'version': 1,
                        'contentType': 'application/vnd.amazonaws.card.generic',
                        'genericAttachments': [
                            {
                                'title': intent_request['sessionAttributes']['Name'],
                                'subTitle': intent_request['sessionAttributes']['Description'],
                                'imageUrl': intent_request['sessionAttributes']['Img'],
                                'attachmentLinkUrl': intent_request['sessionAttributes']['Link']
                            }
                        ]
                    }
    
        )
        
    recipesItems.clear()
    recommend.clear()
    print(recipesItems, recommend)


""" --- Intents --- """
def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    logger.debug('dispatch userId={}, intentName={}'.format(
        intent_request['userId'], intent_request['currentIntent']['name']))

    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'MenuProvide':
        return provide_menu(intent_request)
    elif intent_name == 'PreferenceCheck':
        return check_preference(intent_request)
        

    raise Exception('Intent with name ' + intent_name + ' not supported')


def lambda_handler(event, context):
    '''
    entry point (lambda)
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    '''
    recipes = table.scan()
    for i in recipes['Items']:
        recipesItems.append(i)
    
    logger.debug('event.bot.name={}'.format(event['bot']['name']))
    return dispatch(event)
