def lambda_handler(event, context):
    # TODO implement
    name = event["currentIntent"]["slots"]["Name"].title()
    response = {
                "dialogAction":
                    {
                     "fulfillmentState":"Fulfilled",
                     "type":"Close","message":
                        {
                          "contentType":"PlainText",
                          "content": "Hi "+name+", good to see you!\nI'm ChefBot :D I can recommend you recipes!\nType Meal or Cuisine!"
                        }
                    }
                }
    return response
