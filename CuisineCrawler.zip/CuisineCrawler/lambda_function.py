# encoding: utf-8
from __future__ import print_function
import logging
import time
import boto3
from botocore.vendored import requests

import requests
import time
from bs4 import BeautifulSoup

# logging module
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # 只輸出INFO & 以上等級的log

# dynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('Cuisines')

cuisineType = ''

""" --- crawler --- """
def crawler(cuisineType):
    
    if cuisineType == 'Korean':
        Menu_url = 'https://icook.tw/categories/61?page=1'
    elif cuisineType == 'Japanese':
        Menu_url = 'https://icook.tw/categories/60?page='
    elif cuisineType == 'Spanish':
        Menu_url = 'https://icook.tw/categories/83?page='
    elif cuisineType == 'Italian':
        Menu_url = 'https://icook.tw/categories/63?page='
    elif cuisineType == 'Thai':
        Menu_url = 'https://icook.tw/categories/62?page='
    
    for i in range(1,2):  # page
        url = Menu_url+str(i)
        # 使用假header
        headers = {
            'user-agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36'}
        re = requests.get(url, headers=headers)
        re.encoding = 'utf8'
        s_content = re.text
        soup = BeautifulSoup(s_content, 'html.parser')
        content = soup.find_all(class_='categories-browse-recipe')
        # print(content)

        # find info in content and append
        for i in content:
            name = i.find(
                class_='browse-recipe-content').find(class_='browse-recipe-name').get('title')
            link = i.find(
                class_='browse-recipe-content').find(class_='browse-recipe-name').get('href')
            img = i.find(class_='browse-recipe-cover-img').get('data-src')
            ingredients = i.find(
                class_='browse-recipe-content-ingredient').get_text('class')
            description = i.find(
                class_='browse-recipe-content-description').get_text('class')

            table.put_item(
                Item={
                    'Name': name,
                    'Link': 'https://icook.tw' + link,  # https://icook.tw
                    'Img': img,
                    'Ingredients': ingredients,
                    'Description': description,
                    'Cuisine' : cuisineType,
                    'TTL': int(time.time())
                }
            )
            # info.append({
            #     'Name': name,
            #     'Link': 'https://icook.tw' + link,  # https://icook.tw
            #     'Img': img,
            #     'Ingredients': ingredients,
            #     'Description': description
            # })
            # time.sleep(3)
    # print("Table status:", table.table_status)


def lambda_handler(event, context):
    '''
    entry point (lambda)
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    '''
    crawler('Korean')
    crawler('Japanese')
    crawler('Spanish')
    crawler('Italian')
    crawler('Thai')

