# encoding: utf-8
from __future__ import print_function
import logging
import time
import boto3
from botocore.vendored import requests
from boto3.dynamodb.conditions import Key, Attr
import random
import json
# logging module
logger = logging.getLogger()
logger.setLevel(logging.INFO)  # 只輸出INFO & 以上等級的log

# cuisine_type setting
cuisines = []
cuisineList = []


# ingredients_type setting
suggest = []
eggList = ['雞蛋', '蛋']
vegList = ['菜', '黃瓜', '冬瓜', '絲瓜', '苦瓜', '茄子',
           '青豆', '菇', '茸', '秋葵', '玉米', '洋蔥', '馬鈴薯', '木耳','甜椒','蘆筍','筍','青椒']
meatList = ['牛肉', '豬肉', '雞肉', '羊肉', '肉', '培根', '香腸', '火腿', '排','雞腿','牛肋','熱狗','牛腱']
seafoodList = ['鮪魚', '鮭魚', '鯛魚', '蝦', '蛤蜊', '魷魚', '蝦仁', '烏賊', '活蝦']


# dynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('Cuisines')

""" --- Helpers to build responses which match the structure of the necessary dialog actions --- """


def get_slots(intent_request):
    return intent_request['currentIntent']['slots']


def elicit_slot(session_attributes, intent_name, slots, slot_to_elicit, message):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'ElicitSlot',
            'intentName': intent_name,
            'slots': slots,
            'slotToElicit': slot_to_elicit,
            'message': message
        }
    }


def close(session_attributes, fulfillment_state, message, responseCard):
    response = {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Close',
            'fulfillmentState': fulfillment_state,
            'message': message,
            'responseCard': responseCard
        }
    }
    
    return response


def delegate(session_attributes, slots):
    return {
        'sessionAttributes': session_attributes,
        'dialogAction': {
            'type': 'Delegate',
            'slots': slots
        }
    }

""" --- suggest cuisines  --- """
def getCuisine(cuisine_type):
    '''
    get the cusine in dynamoDB
    '''
    
    cuisine = table.scan(
        FilterExpression=Attr('Cuisine').eq(cuisine_type)
    )
    for i in cuisine['Items']:
        cuisineList.append(i)

def suggestCuisine(ingredient_type):
    '''
    search ingredients in cuisine
    '''
    suggestBool = False
    print(cuisineList)
    print(ingredient_type)


    if ingredient_type == 'Egg':
        ingredientsList = eggList

    elif ingredient_type == 'Veg':
        ingredientsList = vegList

    elif ingredient_type == 'Meat':
        ingredientsList = meatList

    else:
        ingredientsList = seafoodList


    for n in cuisineList:
        for i in ingredientsList:
            if i in n['Ingredients']:
                suggestBool = True

        if suggestBool == True:
            suggest.append(n)
        else:
            continue
        suggestBool = False

    print(suggest)

""" --- Helper Functions --- """
def parse_int(n):
    try:
        return int(n)
    except ValueError:
        return float('nan')


def build_validation_result(is_valid, violated_slot, message_content):
    if message_content is None:
        return {
            'isValid': is_valid,
            'violatedSlot': violated_slot
        }

    return {
        'isValid': is_valid,
        'violatedSlot': violated_slot,
        'message': {'contentType': 'PlainText', 'content': message_content}
    }


def validate_provide_menu(cuisine_type, ingredient_type):
    cuisine_types = ['korean', 'japanese',
                     'spanish','italian', 'thai']
    ingredient_types = ['egg', 'veg', 'meat', 'seafood']
    if cuisine_type is not None and cuisine_type.lower() not in cuisine_types:
        return build_validation_result(False,
                                       'CuisineType',
                                       'We do not have {} recipes, would you like a different type of meal?'
                                       'Try Italian?Japanese?Korean?'.format(cuisine_type))

    if ingredient_type is not None and ingredient_type.lower() not in ingredient_types:
        return build_validation_result(False, 'IngredientType',
                                       'We do not have {} recipes, would you like a different type of ingredient?'
                                       'Try veg?meat?fish?egg?'.format(ingredient_type))
                                

    return build_validation_result(True, None, None)


""" --- Functions that control the bot's behavior --- """


def provide_cuisine(intent_request):
    """
    Performs dialog management and fulfillment for providing menus.
    Beyond fulfillment, the implementation of this intent demonstrates the use of the elicitSlot dialog action
    in slot validation and re-prompting.
    """
    cuisine_type = get_slots(intent_request)["CuisineType"]
    ingredient_type = get_slots(intent_request)["IngredientType"]
    source = intent_request['invocationSource']

    
    if source == 'DialogCodeHook':
        # Perform basic validation on the supplied input slots.
        # Use the elicitSlot dialog action to re-prompt for the first violation
        # detected.
        slots = get_slots(intent_request)

        validation_result = validate_provide_menu(
            cuisine_type, ingredient_type)
        if not validation_result['isValid']:
            slots[validation_result['violatedSlot']] = None
            return elicit_slot(intent_request['sessionAttributes'],
                               intent_request['currentIntent']['name'],
                               slots,
                               validation_result['violatedSlot'],
                               validation_result['message'])

        # Pass the cuisine back through session attributes to be used in various prompts defined
        # on the bot model.
        output_session_attributes = intent_request[
            'sessionAttributes'] if intent_request['sessionAttributes'] is not None else {}

        if cuisine_type is not None:
            getCuisine(cuisine_type)
            if ingredient_type is not None:

                suggestCuisine(ingredient_type)
                output_session_attributes = suggest[
                    random.randrange(len(suggest))]
                print(output_session_attributes)
                
                    
        return delegate(output_session_attributes, get_slots(intent_request))

    # Provide the recipe, and rely on the goodbye message of the bot to define the message to the end user.
    # In a real bot, this would likely involve a call to a backend service.
    return close(intent_request['sessionAttributes'],
                 'Fulfilled',
                 {'contentType': 'PlainText',
                  'content': 'Your {} recipe is '.format(cuisine_type) + "\n" + intent_request['sessionAttributes']['Name']+ "\n" +intent_request['sessionAttributes']['Link']
                  },
                 {
                    'version': 1,
                    'contentType': 'application/vnd.amazonaws.card.generic',
                    'genericAttachments': [
                        {
                            'title': intent_request['sessionAttributes']['Name'],
                            'subTitle': intent_request['sessionAttributes']['Description'],
                            'imageUrl': intent_request['sessionAttributes']['Img'],
                            'attachmentLinkUrl': intent_request['sessionAttributes']['Link']
                        }
                    ]
                }

    )
    
def check_preference(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    source = intent_request['invocationSource']

    if source == 'DialogCodeHook':
        output_session_attributes = suggest[random.randrange(len(suggest))]
        print(output_session_attributes)
        return delegate(output_session_attributes, get_slots(intent_request))
                
    return close(intent_request['sessionAttributes'],
            'Fulfilled',
                     {'contentType': 'PlainText',
                      'content': 'Your new recipe is '+ "\n" + intent_request['sessionAttributes']['Name']+ "\n" +intent_request['sessionAttributes']['Link']
                      },
                     {
                        'version': 1,
                        'contentType': 'application/vnd.amazonaws.card.generic',
                        'genericAttachments': [
                            {
                                'title': intent_request['sessionAttributes']['Name'],
                                'subTitle': intent_request['sessionAttributes']['Description'],
                                'imageUrl': intent_request['sessionAttributes']['Img'],
                                'attachmentLinkUrl': intent_request['sessionAttributes']['Link']
                            }
                        ]
                    }
    
        )
        
    cuisineList.clear()
    suggest.clear()
    print(cuisineList, suggest)
        
    
    
""" --- Intents --- """
def dispatch(intent_request):
    """
    Called when the user specifies an intent for this bot.
    """
    logger.debug('dispatch userId={}, intentName={}'.format(
        intent_request['userId'], intent_request['currentIntent']['name']))

    intent_name = intent_request['currentIntent']['name']

    # Dispatch to your bot's intent handlers
    if intent_name == 'CuisineProvide':
        return provide_cuisine(intent_request)
    elif intent_name == 'PreferenceCheck':
        return check_preference(intent_request)
        
    raise Exception('Intent with name ' + intent_name + ' not supported')


def lambda_handler(event, context):
    '''
    entry point (lambda)
    Route the incoming request based on intent.
    The JSON body of the request is provided in the event slot.
    '''
    # cuisineList.clear()
    # suggest.clear()
    # print(cuisineList, suggest)
    
    logger.debug('event.bot.name={}'.format(event['bot']['name']))
    return dispatch(event)
